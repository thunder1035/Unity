# Unity
An texture pack for MineClone 2 and 5.

Version
===========
(Alpha)0.1

Special thanks to 
===========
CyanideX for creating the texture pack.

# License
licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License
(by-nc-sa 4.0)

========
No longer maintained, the project is closed
